<footer class="footer">
    <div class="container">
        <p>© <?php echo date('Y'); ?> <?php echo htmlspecialchars(get_setting('site_name')); ?></p>
    </div>
</footer>
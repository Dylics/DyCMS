<div class="content">
    <div class="card">
        <div class="card-body text-center">
            <h1>404</h1>
            <p>Страница не найдена</p>
            <a href="/" class="btn btn-modern">Вернуться на главную</a>
        </div>
    </div>
</div>